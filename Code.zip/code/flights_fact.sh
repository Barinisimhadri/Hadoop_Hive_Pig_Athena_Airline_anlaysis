plane_data = LOAD 'airline_db_cur.plane_data' USING org.apache.hive.hcatalog.pig.HCatLoader();
carriers_data = LOAD 'airline_db_cur.carriers' USING org.apache.hive.hcatalog.pig.HCatLoader();
airport_data = LOAD 'airline_db_cur.airports' USING org.apache.hive.hcatalog.pig.HCatLoader();
derived_data = LOAD 'airline_db_cur.detailed_data' USING org.apache.hive.hcatalog.pig.HCatLoader();

plane_data_manu = FOREACH plane_data GENERATE tailnum,manufacturer;
carriers_man = FOREACH carriers_data GENERATE code,description;

derived_data_transformed = FOREACH derived_data GENERATE year,month,flightnum,tailnum,uniquecarrier,(int)arrdelay,(int)depdelay,(int)distance,(int)cancelled,(int)diverted;

derived_grouped_data = GROUP derived_data_transformed BY (year, month, flightnum, tailnum, uniquecarrier);

derived_avg_arr = FOREACH derived_grouped_data GENERATE (derived_data_transformed.year,derived_data_transformed.month,derived_data_transformed.flightnum,derived_data_transformed.tailnum,derived_data_transformed.uniquecarrier),AVG(derived_data_transformed.arrdelay) as avg_arr_delay,AVG(derived_data_transformed.depdelay) as avg_dep_delay,AVG(derived_data_transformed.distance) as avg_distance,MAX(derived_data_transformed.distance) as max_distance,SUM(derived_data_transformed.cancelled) as tot_cancelled_flights,SUM(derived_data_transformed.diverted) as tot_diverted_flights;

derived_avg_arr_tr = FOREACH derived_avg_arr GENERATE FLATTEN($0.$0) as year,FLATTEN($0.$1) as month,FLATTEN($0.$2) as flightnum,FLATTEN($0.$3) as tailnum,FLATTEN($0.$4) as uniquecarrier,$1,$2,$3,$4,$5,$6;

derived_avg_arr_flight = JOIN derived_avg_arr_tr BY flightnum, carriers_data BY code;

result_crr = FOREACH derived_avg_arr_flight GENERATE derived_avg_arr_tr::year,derived_avg_arr_tr::month,derived_avg_arr_tr::flightnum,derived_avg_arr_tr::tailnum,derived_avg_arr_tr::uniquecarrier,derived_avg_arr_tr::avg_arr_delay,derived_avg_arr_tr::avg_dep_delay,derived_avg_arr_tr::avg_distance,derived_avg_arr_tr::max_distance,derived_avg_arr_tr::tot_cancelled_flights,derived_avg_arr_tr::tot_diverted_flights,carriers_data::description as airline_name;

result_crr_man_join = JOIN result_crr by tailnum,plane_data_manu by tailnum;

result_crr_man = FOREACH result_crr_man_join GENERATE result_crr::derived_avg_arr_tr::year,result_crr::derived_avg_arr_tr::month,result_crr::derived_avg_arr_tr::flightnum,result_crr::derived_avg_arr_tr::tailnum,result_crr::derived_avg_arr_tr::uniquecarrier,result_crr::derived_avg_arr_tr::avg_arr_delay,result_crr::derived_avg_arr_tr::avg_dep_delay,result_crr::derived_avg_arr_tr::avg_distance,result_crr::derived_avg_arr_tr::max_distance,result_crr::derived_avg_arr_tr::tot_cancelled_flights,result_crr::derived_avg_arr_tr::tot_diverted_flights,result_crr::airline_name,plane_data_manu::manufacturer;

final = FOREACH result_crr_man GENERATE month as month,flightnum as flightnum,tailnum as tailnum,uniquecarrier as uniquecarrier,avg_arr_delay as avg_arr_delay,avg_dep_delay as avg_dep_delay,avg_distance as avg_distance,max_distance as max_distance,tot_cancelled_flights as tot_cancelled_flights,tot_diverted_flights as tot_diverted_flights,airline_name as airline_name,manufacturer as manufacturer,(avg_arr_delay < 0 ? 'Punctual' : 'Not Punctual') as punctuality_code,ToString(CurrentTime(),'yyyy-MM-dd') as load_dt:chararray, ToString(CurrentTime(),'yyyy-MM-dd HH:mm:ss') as load_dtm:chararray,year as year;

STORE final INTO 'airline_db_cur.flight_facts' USING org.apache.hive.hcatalog.pig.HCatStorer();