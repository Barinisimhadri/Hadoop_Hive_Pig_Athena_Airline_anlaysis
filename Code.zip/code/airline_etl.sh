./aws_emr_copy.sh
./hdfs_put_script.sh
pig -useHCatalog airports_pig.sh
pig -useHCatalog detailed_data_pig.sh
pig -useHCatalog carriers_pig.sh
pig -useHCatalog plane-data_pig.sh
pig -useHCatalog flights_fact.sh
./distcp.sh