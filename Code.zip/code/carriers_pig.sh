data = LOAD 'airline_db_raw.carriers' USING org.apache.hive.hcatalog.pig.HCatLoader();
data_transformed = FOREACH data GENERATE code, description, ToString(CurrentTime(),'yyyy-MM-dd') as load_dt:chararray, ToString(CurrentTime(),'yyyy-MM-dd HH:mm:ss') as load_dtm:chararray;
STORE data_transformed INTO 'airline_db_cur.carriers' USING org.apache.hive.hcatalog.pig.HCatStorer();