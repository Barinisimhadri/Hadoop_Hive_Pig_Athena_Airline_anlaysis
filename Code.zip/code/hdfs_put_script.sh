#!/bin/bash

#hdfs put command

current_date=$(date +%Y%m%d)

#Copying the existing data to archival

#Checking whether existing file is present or not
airports_file_count=$(hadoop fs -count /airline_data/airports | awk '{print $2}')
carriers_file_count=$(hadoop fs -count /airline_data/carriers | awk '{print $2}')
plane_file_count=$(hadoop fs -count /airline_data/plane-data | awk '{print $2}')
detailed_data_file_count=$(hadoop fs -count /airline_data/detailed_data | awk '{print $2}')

if [ $airports_file_count -eq 0 ]
then
    hadoop fs -put -f airline_source_data/airports/airports.csv /airline_data/airports
else
    hadoop fs -mkdir -p airline_data/archival/airports/$current_date
    hadoop fs -cp -f /airline_data/airports/airports.csv airline_data/archival/airports/$current_date/
    hadoop fs -put -f airline_source_data/airports/airports.csv /airline_data/airports
fi

if [ $carriers_file_count -eq 0 ]
then
    hadoop fs -put -f airline_source_data/carriers/carriers.csv /airline_data/carriers
else
    hadoop fs -mkdir -p airline_data/archival/carriers/$current_date
    hadoop fs -cp -f /airline_data/carriers/carriers.csv airline_data/archival/carriers/$current_date/
    hadoop fs -put -f airline_source_data/carriers/carriers.csv  /airline_data/carriers
fi

if [ $plane_file_count -eq 0 ]
then
    hadoop fs -put -f airline_source_data/plane-data/plane-data.csv /airline_data/plane-data
else
    hadoop fs -mkdir -p airline_data/archival/plane-data/$current_date
    hadoop fs -cp -f /airline_data/plane-data/plane-data.csv airline_data/archival/plane-data/$current_date/
    hadoop fs -put -f airline_source_data/plane-data/plane-data.csv  /airline_data/plane-data
fi

if [ $detailed_data_file_count -eq 0 ]
then
    hadoop fs -put -f airline_source_data/detailed_data/detailed_data.csv /airline_data/detailed_data
else
    hadoop fs -mkdir -p airline_data/archival/detailed_data/$current_date
    hadoop fs -cp -f /airline_data/detailed_data/detailed_data.csv airline_data/archival/detailed_data/$current_date/
    hadoop fs -put -f airline_source_data/detailed_data/detailed_data.csv  /airline_data/detailed_data
fi