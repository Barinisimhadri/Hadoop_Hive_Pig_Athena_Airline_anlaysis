aws s3 cp s3://airline-data-projectpro/source_data/plane-data.csv airline_source_data/plane-data/
aws s3 cp s3://airline-data-projectpro/source_data/detailed_data.csv airline_source_data/detailed_data/
aws s3 cp s3://airline-data-projectpro/source_data/carriers.csv airline_source_data/carriers/
aws s3 cp s3://airline-data-projectpro/source_data/airports.csv airline_source_data/airports/
